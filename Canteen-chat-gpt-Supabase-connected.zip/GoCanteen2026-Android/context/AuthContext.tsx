import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { User } from '../types';
import { supabase, supabaseEnabled, internalEmailForLogin } from '../supabase';

interface AuthContextType {
    user: User | null;
    login: (user: User) => void;
    loginWithCredentials: (userId: string, password: string, localUsers: User[]) => Promise<{ ok: boolean; error?: string }>;
    logout: () => void;
    updateUser: (updatedUser: User) => void;
    loading: boolean;
}
const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [user, setUser] = useState<User | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const stored = sessionStorage.getItem('canteen_user');
        if (stored) { try { setUser(JSON.parse(stored)); } catch {} }
        setLoading(false);
    }, []);

    const login = useCallback((u: User) => {
        sessionStorage.setItem('canteen_user', JSON.stringify(u));
        setUser(u);
    }, []);

    const loginWithCredentials = useCallback(async (userId: string, password: string, localUsers: User[]) => {
        const local = localUsers.find(u => u.id === userId);
        if (!local) return { ok: false, error: 'Invalid User ID or Password.' };
        if (local.status === 'blocked') return { ok: false, error: 'Your account is blocked. Please contact the administrator.' };

        // Admin and provisioned employees authenticate against Supabase Auth.
        if (supabaseEnabled && supabase) {
            const { data, error } = await supabase.auth.signInWithPassword({
                email: internalEmailForLogin(userId),
                password,
            });
            if (!error && data.user) {
                const { data: profile } = await supabase.from('profiles').select('*').eq('id', data.user.id).maybeSingle();
                const resolved: User = {
                    ...local,
                    id: profile?.employee_code || profile?.sr_number || local.id,
                    name: profile?.full_name || local.name,
                    mobile: profile?.mobile_number || local.mobile,
                    role: profile?.role || local.role,
                };
                login(resolved);
                return { ok: true };
            }
            // Keep local fallback for legacy employees not yet provisioned in Supabase Auth.
            if (local.role !== 'admin' && local.password === password) { login(local); return { ok: true }; }
            return { ok: false, error: error?.message || 'Invalid User ID or Password.' };
        }

        if (local.password !== password) return { ok: false, error: 'Invalid User ID or Password.' };
        login(local);
        return { ok: true };
    }, [login]);

    const logout = useCallback(async () => {
        if (supabaseEnabled && supabase) await supabase.auth.signOut();
        sessionStorage.removeItem('canteen_user');
        setUser(null);
    }, []);

    const updateUser = useCallback((u: User) => {
        sessionStorage.setItem('canteen_user', JSON.stringify(u));
        setUser(u);
    }, []);

    return <AuthContext.Provider value={{ user, login, loginWithCredentials, logout, updateUser, loading }}>{children}</AuthContext.Provider>;
};
export const useAuth = () => { const context = useContext(AuthContext); if (!context) throw new Error('useAuth must be used within an AuthProvider'); return context; };
