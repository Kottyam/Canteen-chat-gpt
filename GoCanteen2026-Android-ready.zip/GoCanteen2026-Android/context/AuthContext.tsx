
import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { User } from '../types';

interface AuthContextType {
    user: User | null;
    login: (user: User) => void;
    logout: () => void;
    updateUser: (updatedUser: User) => void;
    loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [user, setUser] = useState<User | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        try {
            const storedUser = sessionStorage.getItem('canteen_user');
            if (storedUser) {
                setUser(JSON.parse(storedUser));
            }
        } catch (error) {
            console.error("Failed to parse user from session storage", error);
        } finally {
            setLoading(false);
        }
    }, []);

    const login = useCallback((userToLogin: User) => {
        sessionStorage.setItem('canteen_user', JSON.stringify(userToLogin));
        setUser(userToLogin);
    }, []);

    const logout = useCallback(() => {
        sessionStorage.removeItem('canteen_user');
        setUser(null);
    }, []);

    const updateUser = useCallback((updatedUser: User) => {
        sessionStorage.setItem('canteen_user', JSON.stringify(updatedUser));
        setUser(updatedUser);
    }, []);

    return (
        <AuthContext.Provider value={{ user, login, logout, updateUser, loading }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};
   