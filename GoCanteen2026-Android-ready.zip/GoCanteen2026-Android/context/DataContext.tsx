
import React, { createContext, useContext, ReactNode } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { User, Order, Prices, Status } from '../types';
import { ADMIN_USER_ID, DEFAULT_ADMIN_PASSWORD } from '../constants';

interface DataContextType {
    users: User[];
    setUsers: React.Dispatch<React.SetStateAction<User[]>>;
    orders: Order[];
    setOrders: React.Dispatch<React.SetStateAction<Order[]>>;
    prices: Prices;
    setPrices: React.Dispatch<React.SetStateAction<Prices>>;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

const initialUsers: User[] = [
    {
        id: ADMIN_USER_ID,
        password: DEFAULT_ADMIN_PASSWORD,
        role: 'admin',
        status: 'active' as Status,
        isFirstLogin: false
    }
];

const initialPrices: Prices = {
    morningTea: 8,
    lunchMeals: 40,
    lunchEgg: 10,
    lunchFishMeat: 25,
    eveningTea: 8
};

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [users, setUsers] = useLocalStorage<User[]>('canteen_users', initialUsers);
    const [orders, setOrders] = useLocalStorage<Order[]>('canteen_orders', []);
    const [prices, setPrices] = useLocalStorage<Prices>('canteen_prices', initialPrices);
    
    return (
        <DataContext.Provider value={{ users, setUsers, orders, setOrders, prices, setPrices }}>
            {children}
        </DataContext.Provider>
    );
};

export const useData = () => {
    const context = useContext(DataContext);
    if (context === undefined) {
        throw new Error('useData must be used within a DataProvider');
    }
    return context;
};
   