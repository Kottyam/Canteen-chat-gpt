
export type Role = 'employee' | 'admin';
export type Status = 'active' | 'blocked';

export interface User {
    id: string; // 5-digit for employee, 'admin' for admin
    password: string;
    role: Role;
    status: Status;
    isFirstLogin?: boolean; // Only for employees
}

export interface OrderItems {
    morningTea: boolean;
    lunchMeals: boolean;
    lunchEgg: boolean;
    lunchFishMeat: boolean;
    eveningTea: boolean;
}

export interface Order {
    id: string; // unique id e.g., `${employeeId}-${date}`
    employeeId: string;
    date: string; // 'YYYY-MM-DD'
    items: OrderItems;
}

export interface Prices {
    morningTea: number;
    lunchMeals: number;
    lunchEgg: number;
    lunchFishMeat: number;
    eveningTea: number;
}
   