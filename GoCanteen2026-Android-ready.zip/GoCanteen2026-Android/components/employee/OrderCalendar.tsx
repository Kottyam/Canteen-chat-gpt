
import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { getMonthName, formatDate } from '../../utils/helpers';
import { Order, OrderItems } from '../../types';

const OrderCalendar: React.FC = () => {
    const { user } = useAuth();
    const { orders, prices } = useData();
    const [currentDate, setCurrentDate] = useState(new Date());
    const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
    
    const userOrders = user ? orders.filter(o => o.employeeId === user.id) : [];

    const startOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    const endOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
    const startDay = startOfMonth.getDay();
    const daysInMonth = endOfMonth.getDate();

    const changeMonth = (offset: number) => {
        setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + offset, 1));
        setSelectedOrder(null);
    };

    const renderDays = () => {
        const days = [];
        for (let i = 0; i < startDay; i++) {
            days.push(<div key={`empty-${i}`} className="border border-gray-200"></div>);
        }
        for (let day = 1; day <= daysInMonth; day++) {
            const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
            const dateString = formatDate(date);
            const orderForDay = userOrders.find(o => o.date === dateString);
            const isToday = formatDate(new Date()) === dateString;

            days.push(
                <div 
                    key={day} 
                    className={`p-2 border border-gray-200 text-center cursor-pointer transition-colors ${orderForDay ? 'bg-primary-100 hover:bg-primary-200' : 'hover:bg-gray-100'} ${isToday ? 'bg-yellow-100' : ''}`}
                    onClick={() => setSelectedOrder(orderForDay || null)}
                >
                    <span className={`flex items-center justify-center w-8 h-8 mx-auto rounded-full ${isToday ? 'font-bold text-primary-700' : ''}`}>
                        {day}
                    </span>
                    {orderForDay && <div className="w-2 h-2 mx-auto mt-1 rounded-full bg-primary-500"></div>}
                </div>
            );
        }
        return days;
    };
    
    const renderOrderDetails = (orderItems: OrderItems) => {
        const items = [];
        let total = 0;
        if (orderItems.morningTea) {
            items.push({name: 'Morning Tea', price: prices.morningTea});
            total += prices.morningTea;
        }
        if (orderItems.lunchMeals) {
            items.push({name: 'Meals', price: prices.lunchMeals});
            total += prices.lunchMeals;
        }
        if (orderItems.lunchEgg) {
            items.push({name: 'Egg', price: prices.lunchEgg});
            total += prices.lunchEgg;
        }
        if (orderItems.lunchFishMeat) {
            items.push({name: 'Fish/Meat', price: prices.lunchFishMeat});
            total += prices.lunchFishMeat;
        }
        if (orderItems.eveningTea) {
            items.push({name: 'Evening Tea', price: prices.eveningTea});
            total += prices.eveningTea;
        }

        if (items.length === 0) {
             return <p className="text-gray-500">No items ordered on this day.</p>;
        }

        return (
            <div>
                <ul className="space-y-1">
                {items.map(item => <li key={item.name} className="flex justify-between"><span>{item.name}</span><span>₹{item.price}</span></li>)}
                </ul>
                <hr className="my-2"/>
                <p className="flex justify-between font-bold"><span>Total</span><span>₹{total.toFixed(2)}</span></p>
            </div>
        );
    };

    return (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
            <div className="p-6 bg-white rounded-lg shadow-md md:col-span-2">
                <div className="flex items-center justify-between mb-4">
                    <button onClick={() => changeMonth(-1)} className="px-3 py-1 text-gray-600 bg-gray-200 rounded-md hover:bg-gray-300">&lt;</button>
                    <h3 className="text-xl font-semibold">{getMonthName(currentDate.getMonth())} {currentDate.getFullYear()}</h3>
                    <button onClick={() => changeMonth(1)} className="px-3 py-1 text-gray-600 bg-gray-200 rounded-md hover:bg-gray-300">&gt;</button>
                </div>
                <div className="grid grid-cols-7 text-xs font-bold text-center text-gray-600">
                    <div>Sun</div><div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div>
                </div>
                <div className="grid grid-cols-7 mt-1 text-sm">{renderDays()}</div>
            </div>
            <div className="p-6 bg-white rounded-lg shadow-md md:col-span-1">
                <h4 className="mb-4 text-lg font-bold text-gray-800">Order Details</h4>
                {selectedOrder ? (
                    <div>
                        <p className="mb-2 font-semibold">Date: {selectedOrder.date}</p>
                        {renderOrderDetails(selectedOrder.items)}
                    </div>
                ) : (
                    <p className="text-gray-500">Select a date with an order to see details.</p>
                )}
            </div>
        </div>
    );
};

export default OrderCalendar;
   