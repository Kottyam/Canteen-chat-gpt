
import React, { useState, useEffect } from 'react';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { OrderItems, Order } from '../../types';
import { formatDate } from '../../utils/helpers';

const initialOrderState: OrderItems = {
    morningTea: false,
    lunchMeals: false,
    lunchEgg: false,
    lunchFishMeat: false,
    eveningTea: false,
};

const OrderForm: React.FC = () => {
    const { user } = useAuth();
    const { orders, setOrders, prices } = useData();
    const [selectedDate, setSelectedDate] = useState<string>(formatDate(new Date()));
    const [currentOrder, setCurrentOrder] = useState<OrderItems>(initialOrderState);
    const [message, setMessage] = useState<{type: 'success' | 'error', text: string} | null>(null);

    useEffect(() => {
        if (!user) return;
        const existingOrder = orders.find(o => o.employeeId === user.id && o.date === selectedDate);
        if (existingOrder) {
            setCurrentOrder(existingOrder.items);
        } else {
            setCurrentOrder(initialOrderState);
        }
    }, [selectedDate, orders, user]);

    const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, checked } = e.target;
        const newOrder = { ...currentOrder, [name]: checked };

        if (name === 'lunchEgg' && checked) {
            newOrder.lunchMeals = true;
        }
        if (name === 'lunchFishMeat' && checked) {
            newOrder.lunchMeals = true;
        }
        if (name === 'lunchMeals' && !checked) {
            newOrder.lunchEgg = false;
            newOrder.lunchFishMeat = false;
        }

        setCurrentOrder(newOrder);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!user) return;

        const orderId = `${user.id}-${selectedDate}`;
        const newOrder: Order = {
            id: orderId,
            employeeId: user.id,
            date: selectedDate,
            items: currentOrder,
        };

        const existingOrderIndex = orders.findIndex(o => o.id === orderId);
        
        if (existingOrderIndex !== -1) {
            const updatedOrders = [...orders];
            updatedOrders[existingOrderIndex] = newOrder;
            setOrders(updatedOrders);
        } else {
            setOrders([...orders, newOrder]);
        }
        
        setMessage({ type: 'success', text: 'Order saved successfully!' });
        setTimeout(() => setMessage(null), 3000);
    };

    return (
        <div className="p-6 bg-white rounded-lg shadow-md">
            <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                    <label htmlFor="date" className="block text-sm font-medium text-gray-700">Select Date</label>
                    <input
                        type="date"
                        id="date"
                        value={selectedDate}
                        onChange={(e) => setSelectedDate(e.target.value)}
                        className="block w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                        required
                    />
                </div>
                
                <fieldset>
                    <legend className="text-lg font-medium text-gray-900">Food Items</legend>
                    <div className="mt-4 space-y-4">
                        <div className="relative flex items-start">
                            <div className="flex items-center h-5">
                                <input id="morningTea" name="morningTea" type="checkbox" checked={currentOrder.morningTea} onChange={handleCheckboxChange} className="w-4 h-4 rounded text-primary-600 border-gray-300 focus:ring-primary-500"/>
                            </div>
                            <div className="ml-3 text-sm">
                                <label htmlFor="morningTea" className="font-medium text-gray-700">Morning Tea (₹{prices.morningTea})</label>
                            </div>
                        </div>
                         <div className="relative flex items-start">
                            <div className="flex items-center h-5">
                                <input id="lunchMeals" name="lunchMeals" type="checkbox" checked={currentOrder.lunchMeals} onChange={handleCheckboxChange} className="w-4 h-4 rounded text-primary-600 border-gray-300 focus:ring-primary-500"/>
                            </div>
                            <div className="ml-3 text-sm">
                                <label htmlFor="lunchMeals" className="font-medium text-gray-700">Lunch: Meals (₹{prices.lunchMeals})</label>
                            </div>
                        </div>
                         <div className="relative flex items-start pl-7">
                            <div className="flex items-center h-5">
                                <input id="lunchEgg" name="lunchEgg" type="checkbox" checked={currentOrder.lunchEgg} onChange={handleCheckboxChange} className="w-4 h-4 rounded text-primary-600 border-gray-300 focus:ring-primary-500"/>
                            </div>
                            <div className="ml-3 text-sm">
                                <label htmlFor="lunchEgg" className="font-medium text-gray-700">+ Egg (₹{prices.lunchEgg})</label>
                            </div>
                        </div>
                         <div className="relative flex items-start pl-7">
                            <div className="flex items-center h-5">
                                <input id="lunchFishMeat" name="lunchFishMeat" type="checkbox" checked={currentOrder.lunchFishMeat} onChange={handleCheckboxChange} className="w-4 h-4 rounded text-primary-600 border-gray-300 focus:ring-primary-500"/>
                            </div>
                            <div className="ml-3 text-sm">
                                <label htmlFor="lunchFishMeat" className="font-medium text-gray-700">+ Fish/Meat (₹{prices.lunchFishMeat})</label>
                            </div>
                        </div>
                         <div className="relative flex items-start">
                            <div className="flex items-center h-5">
                                <input id="eveningTea" name="eveningTea" type="checkbox" checked={currentOrder.eveningTea} onChange={handleCheckboxChange} className="w-4 h-4 rounded text-primary-600 border-gray-300 focus:ring-primary-500"/>
                            </div>
                            <div className="ml-3 text-sm">
                                <label htmlFor="eveningTea" className="font-medium text-gray-700">Evening Tea (₹{prices.eveningTea})</label>
                            </div>
                        </div>
                    </div>
                </fieldset>
                
                <div>
                    <button type="submit" className="w-full px-4 py-2 text-sm font-medium text-white border border-transparent rounded-md shadow-sm bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
                        Save Order
                    </button>
                </div>
                 {message && (
                    <div className={`p-3 mt-4 text-sm rounded-md ${message.type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                        {message.text}
                    </div>
                )}
            </form>
        </div>
    );
};

export default OrderForm;
   