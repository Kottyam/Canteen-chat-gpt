
import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { User, Status } from '../../types';
import { DEFAULT_EMPLOYEE_PASSWORD } from '../../constants';

const EmployeeManagement: React.FC = () => {
    const { users, setUsers } = useData();
    const [newEmployeeId, setNewEmployeeId] = useState('');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    const employees = users.filter(u => u.role === 'employee');

    const handleAddEmployee = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');

        if (!/^\d{5}$/.test(newEmployeeId)) {
            setError('Employee ID must be exactly 5 digits.');
            return;
        }
        if (users.some(u => u.id === newEmployeeId)) {
            setError('Employee ID already exists.');
            return;
        }

        const newEmployee: User = {
            id: newEmployeeId,
            password: DEFAULT_EMPLOYEE_PASSWORD,
            role: 'employee',
            status: 'active' as Status,
            isFirstLogin: true,
        };
        setUsers([...users, newEmployee]);
        setSuccess(`Employee ${newEmployeeId} added successfully.`);
        setNewEmployeeId('');
    };
    
    const toggleStatus = (id: string) => {
        setUsers(users.map(u => u.id === id ? {...u, status: u.status === 'active' ? 'blocked' : 'active'} : u));
    };
    
    const resetPassword = (id: string) => {
        setUsers(users.map(u => u.id === id ? {...u, password: DEFAULT_EMPLOYEE_PASSWORD, isFirstLogin: true} : u));
    };

    return (
        <div>
            <h3 className="mb-6 text-2xl font-bold text-gray-800">Employee Management</h3>
            
            <form onSubmit={handleAddEmployee} className="p-4 mb-6 border border-gray-200 rounded-lg bg-gray-50">
                <h4 className="mb-2 font-semibold text-gray-700">Add New Employee</h4>
                {error && <div className="p-2 mb-2 text-sm text-red-700 bg-red-100 rounded-md">{error}</div>}
                {success && <div className="p-2 mb-2 text-sm text-green-700 bg-green-100 rounded-md">{success}</div>}
                <div className="flex items-center space-x-2">
                    <input
                        type="text"
                        value={newEmployeeId}
                        onChange={(e) => setNewEmployeeId(e.target.value)}
                        placeholder="5-digit Employee ID"
                        maxLength={5}
                        className="flex-grow px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    />
                    <button type="submit" className="px-4 py-2 text-sm font-medium text-white border border-transparent rounded-md shadow-sm bg-primary-600 hover:bg-primary-700">Add</button>
                </div>
            </form>

            <div className="overflow-x-auto">
                <table className="min-w-full bg-white divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Employee ID</th>
                            <th className="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Status</th>
                            <th className="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {employees.map(emp => (
                            <tr key={emp.id}>
                                <td className="px-6 py-4 text-sm font-medium text-gray-900 whitespace-nowrap">{emp.id}</td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${emp.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                        {emp.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 space-x-2 text-sm font-medium whitespace-nowrap">
                                    <button onClick={() => toggleStatus(emp.id)} className={`px-3 py-1 rounded-md text-white text-xs ${emp.status === 'active' ? 'bg-yellow-500 hover:bg-yellow-600' : 'bg-green-500 hover:bg-green-600'}`}>
                                        {emp.status === 'active' ? 'Block' : 'Unblock'}
                                    </button>
                                    <button onClick={() => resetPassword(emp.id)} className="px-3 py-1 text-white rounded-md bg-primary-500 hover:bg-primary-600 text-xs">Reset Password</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default EmployeeManagement;
   