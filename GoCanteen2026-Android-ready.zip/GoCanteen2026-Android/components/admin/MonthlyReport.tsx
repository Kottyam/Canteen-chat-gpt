
import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { getMonthName } from '../../utils/helpers';
import { OrderItems, User } from '../../types';

interface ReportRow {
    employeeId: string;
    counts: {
        morningTea: number;
        lunchMeals: number;
        lunchEgg: number;
        lunchFishMeat: number;
        eveningTea: number;
    };
    totals: {
        morningTea: number;
        lunchMeals: number;
        lunchEgg: number;
        lunchFishMeat: number;
        eveningTea: number;
    };
    grandTotal: number;
}

const MonthlyReport: React.FC = () => {
    const { orders, users, prices } = useData();
    const today = new Date();
    const [selectedMonth, setSelectedMonth] = useState(today.getMonth());
    const [selectedYear, setSelectedYear] = useState(today.getFullYear());

    const employees = users.filter(u => u.role === 'employee');

    const monthlyData = useMemo(() => {
        const monthString = (selectedMonth + 1).toString().padStart(2, '0');
        const filteredOrders = orders.filter(o => o.date.startsWith(`${selectedYear}-${monthString}`));

        const report = employees.map((employee: User) => {
            const employeeOrders = filteredOrders.filter(o => o.employeeId === employee.id);
            
            const counts = employeeOrders.reduce((acc, order) => {
                const items: (keyof OrderItems)[] = ['morningTea', 'lunchMeals', 'lunchEgg', 'lunchFishMeat', 'eveningTea'];
                items.forEach(item => {
                    if(order.items[item]) acc[item]++;
                });
                return acc;
            }, { morningTea: 0, lunchMeals: 0, lunchEgg: 0, lunchFishMeat: 0, eveningTea: 0 });

            const totals = {
                morningTea: counts.morningTea * prices.morningTea,
                lunchMeals: counts.lunchMeals * prices.lunchMeals,
                lunchEgg: counts.lunchEgg * prices.lunchEgg,
                lunchFishMeat: counts.lunchFishMeat * prices.lunchFishMeat,
                eveningTea: counts.eveningTea * prices.eveningTea,
            };

            const grandTotal = Object.values(totals).reduce((sum, val) => sum + val, 0);

            return { employeeId: employee.id, counts, totals, grandTotal };
        });

        return report;
    }, [selectedMonth, selectedYear, orders, users, prices, employees]);
    
    const overallTotal = useMemo(() => monthlyData.reduce((sum, row) => sum + row.grandTotal, 0), [monthlyData]);
    
    const handlePrint = () => {
        window.print();
    };

    return (
        <div>
            <h3 className="mb-6 text-2xl font-bold text-gray-800">Monthly Report</h3>
            <div className="flex items-center p-4 mb-6 space-x-4 border border-gray-200 rounded-lg bg-gray-50">
                <div>
                    <label htmlFor="month" className="block text-sm font-medium text-gray-700">Month</label>
                    <select id="month" value={selectedMonth} onChange={e => setSelectedMonth(Number(e.target.value))} className="block w-full py-2 pl-3 pr-10 mt-1 text-base border-gray-300 rounded-md focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm">
                        {Array.from({length: 12}, (_, i) => <option key={i} value={i}>{getMonthName(i)}</option>)}
                    </select>
                </div>
                 <div>
                    <label htmlFor="year" className="block text-sm font-medium text-gray-700">Year</label>
                    <select id="year" value={selectedYear} onChange={e => setSelectedYear(Number(e.target.value))} className="block w-full py-2 pl-3 pr-10 mt-1 text-base border-gray-300 rounded-md focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm">
                        {Array.from({length: 5}, (_, i) => today.getFullYear() - i).map(y => <option key={y} value={y}>{y}</option>)}
                    </select>
                </div>
                <div className="pt-6">
                    <button onClick={handlePrint} className="px-4 py-2 text-sm font-medium text-white border border-transparent rounded-md shadow-sm bg-gray-600 hover:bg-gray-700">
                        Print
                    </button>
                </div>
            </div>

            <div className="overflow-x-auto">
                <table className="min-w-full bg-white divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="px-4 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">Emp ID</th>
                            <th className="px-4 py-3 text-xs font-medium tracking-wider text-center text-gray-500 uppercase">Meals</th>
                            <th className="px-4 py-3 text-xs font-medium tracking-wider text-center text-gray-500 uppercase">Egg</th>
                            <th className="px-4 py-3 text-xs font-medium tracking-wider text-center text-gray-500 uppercase">Fish/Meat</th>
                            <th className="px-4 py-3 text-xs font-medium tracking-wider text-center text-gray-500 uppercase">Tea (M+E)</th>
                            <th className="px-4 py-3 text-xs font-medium tracking-wider text-right text-gray-500 uppercase">Total Payable</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {monthlyData.map((row: ReportRow) => (
                            <tr key={row.employeeId}>
                                <td className="px-4 py-4 text-sm font-medium text-gray-900 whitespace-nowrap">{row.employeeId}</td>
                                <td className="px-4 py-4 text-sm text-center text-gray-500 whitespace-nowrap">{row.counts.lunchMeals}</td>
                                <td className="px-4 py-4 text-sm text-center text-gray-500 whitespace-nowrap">{row.counts.lunchEgg}</td>
                                <td className="px-4 py-4 text-sm text-center text-gray-500 whitespace-nowrap">{row.counts.lunchFishMeat}</td>
                                <td className="px-4 py-4 text-sm text-center text-gray-500 whitespace-nowrap">{row.counts.morningTea + row.counts.eveningTea}</td>
                                <td className="px-4 py-4 text-sm font-semibold text-right text-gray-900 whitespace-nowrap">₹{row.grandTotal.toFixed(2)}</td>
                            </tr>
                        ))}
                    </tbody>
                    <tfoot className="bg-gray-100">
                        <tr>
                            <td colSpan={5} className="px-4 py-3 text-sm font-bold text-right text-gray-700">Monthly Total Expense</td>
                            <td className="px-4 py-3 text-sm font-extrabold text-right text-gray-900">₹{overallTotal.toFixed(2)}</td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    );
};

export default MonthlyReport;
   