
import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { formatDate } from '../../utils/helpers';
import { OrderItems } from '../../types';

const DailySummary: React.FC = () => {
    const { orders, prices } = useData();
    const [selectedDate, setSelectedDate] = useState<string>(formatDate(new Date()));

    const dailySummary = useMemo(() => {
        const todaysOrders = orders.filter(o => o.date === selectedDate);

        const counts = {
            morningTea: 0,
            lunchMeals: 0,
            lunchEgg: 0,
            lunchFishMeat: 0,
            eveningTea: 0,
        };

        todaysOrders.forEach(order => {
            const items: (keyof OrderItems)[] = ['morningTea', 'lunchMeals', 'lunchEgg', 'lunchFishMeat', 'eveningTea'];
            items.forEach(item => {
                if (order.items[item]) {
                    counts[item]++;
                }
            });
        });

        const totalRevenue = 
            (counts.morningTea * prices.morningTea) +
            (counts.lunchMeals * prices.lunchMeals) +
            (counts.lunchEgg * prices.lunchEgg) +
            (counts.lunchFishMeat * prices.lunchFishMeat) +
            (counts.eveningTea * prices.eveningTea);

        return { counts, totalRevenue };
    }, [selectedDate, orders, prices]);

    const summaryItems = [
        { label: 'Morning Tea', count: dailySummary.counts.morningTea },
        { label: 'Meals', count: dailySummary.counts.lunchMeals },
        { label: 'Eggs', count: dailySummary.counts.lunchEgg },
        { label: 'Fish/Meat', count: dailySummary.counts.lunchFishMeat },
        { label: 'Evening Tea', count: dailySummary.counts.eveningTea },
    ];

    return (
        <div>
            <h3 className="mb-6 text-2xl font-bold text-gray-800">Daily Order Summary</h3>

            <div className="max-w-md p-4 mb-6 border border-gray-200 rounded-lg bg-gray-50">
                <label htmlFor="date" className="block text-sm font-medium text-gray-700">Select Date</label>
                <input
                    type="date"
                    id="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="block w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    required
                />
            </div>

            <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-5">
                {summaryItems.map(item => (
                    <div key={item.label} className="p-4 text-center bg-white border rounded-lg shadow-sm">
                        <p className="text-sm font-medium text-gray-500">{item.label}</p>
                        <p className="mt-1 text-3xl font-semibold text-gray-900">{item.count}</p>
                    </div>
                ))}
            </div>

            <div className="p-6 mt-6 text-center rounded-lg bg-primary-600">
                <p className="text-lg font-medium text-white">Total Revenue for the Day</p>
                <p className="mt-1 text-4xl font-bold text-white">₹{dailySummary.totalRevenue.toFixed(2)}</p>
            </div>
        </div>
    );
};

export default DailySummary;
   